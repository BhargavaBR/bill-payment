package com.cts.billpayment.service;
import java.util.List;

import com.cts.billpayment.entities.Help;

public interface HelpService {
	int savehelp(Help help);
		 public List<Help> helplist();
		 
		}

