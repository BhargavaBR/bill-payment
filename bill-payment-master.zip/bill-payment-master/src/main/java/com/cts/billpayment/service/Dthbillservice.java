package com.cts.billpayment.service;

import com.cts.billpayment.entities.Dth;

public interface Dthbillservice 
{
public int savebill(Dth dth);
}
