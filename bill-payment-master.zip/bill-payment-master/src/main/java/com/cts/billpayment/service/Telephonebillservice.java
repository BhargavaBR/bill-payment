package com.cts.billpayment.service;

import com.cts.billpayment.entities.Dth;
import com.cts.billpayment.entities.telephone;

public interface Telephonebillservice {
	public int savebill(telephone phone);
}
