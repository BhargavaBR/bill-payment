package com.cts.billpayment.service;

import com.cts.billpayment.entities.electricity;

public interface ebillservice
{
public int savebill(electricity electricity);
}
