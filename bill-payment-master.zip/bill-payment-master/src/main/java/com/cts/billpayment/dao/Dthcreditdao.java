package com.cts.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.cts.billpayment.entities.Dthcredit;

public interface Dthcreditdao extends CrudRepository<Dthcredit, String>
{

}
