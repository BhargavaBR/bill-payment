package com.cts.billpayment.dao;



import org.springframework.data.repository.CrudRepository;

import com.cts.billpayment.entities.Aminlogin;


public interface Admindao extends CrudRepository<Aminlogin, String>
{

}
