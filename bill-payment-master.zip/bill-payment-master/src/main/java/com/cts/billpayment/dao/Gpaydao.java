package com.cts.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.cts.billpayment.entities.Gpay;

public interface Gpaydao extends CrudRepository<Gpay,String>{

	

}
