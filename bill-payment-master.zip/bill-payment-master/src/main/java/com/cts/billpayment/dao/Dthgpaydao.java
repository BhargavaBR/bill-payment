package com.cts.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.cts.billpayment.entities.Dthgpay;

public interface Dthgpaydao extends CrudRepository<Dthgpay,String>{

}
