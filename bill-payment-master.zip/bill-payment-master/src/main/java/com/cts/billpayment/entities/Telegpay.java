package com.cts.billpayment.entities;

public class Telegpay {

}
